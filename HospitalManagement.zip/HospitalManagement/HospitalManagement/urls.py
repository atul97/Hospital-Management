from django.contrib import admin
from django.urls import path
from Hospital.views import *
from rest_framework.authtoken import views
#from django.contrib.auth.views import login

urlpatterns = [
    path('admin/', admin.site.urls),
    path('about/',About,name="about"),
    path('',Index,name="home"),
    path('main/',Index,name="main"),
    path('admin_login/',Login,name='login'),
    path('logout/',Logout_admin,name="logout"),
    path('contact/',Contact,name="contact"),
    path('view_doctor',View_Doctor,name="view_doctor"),
    path('add_doctor',Add_Doctor,name="add_doctor"),
    path('delete_doctor(?P<slug:did>)',Delete_Doctor,name="delete_doctor"),
    path('view_patient',View_Patient,name="view_patient"),
    path('add_patient',Add_Patient,name="add_patient"),
    path('delete_patient(?P<slug:pid>)',Delete_Patient,name="delete_patient"),
    path('book_appointment',Book_Appointment,name="book_appointment"),
    path('view_appointment',View_Appointment,name="view_appointment"),
    path('delete_appointment(?P<slug:aid>)',Delete_Appointment,name="delete_appointment"),

    path('doctor_data/<id>/<username>/<password>',doctor_list,),
    #path('search_login',remote_login,name="remote_login"),
    path('search/<sid>',check_id,name="Search"),
    path('api-token-auth/',views.obtain_auth_token,name ='api-token-auth'),
    #path('login/',login,name='login')
    path('outside/auth/login/',LoginView.as_view()),
    path('outside/auth/logout/',LogoutView.as_view()),


    path('book_diagnose/',DiagnoseView,name="diagnose"),
    path('diagnose/outpatient/',DiagnoseOutPatientView,name="outpatient_diagnose_detail"),

    path('pharmacy',PharmacyView,name="pharmacy"),


]

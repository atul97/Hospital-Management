from django.shortcuts import render,redirect
from django.contrib.auth import authenticate,login,logout
from .models import *
from datetime import date
from django.db.models import Count


from rest_framework import status
from rest_framework.views import APIView
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.authentication import TokenAuthentication
from rest_framework.authtoken.models import Token

from Hospital.serializer import DoctorSerializer,PatientSerializer,AppointmentSerializer,Appointment_Count_Serializer,LoginSerializer
import requests
import json

'''
def remote_login(request):
    error=""
    id=""
    if request.method=='POST':
        uname = request.POST['uname']
        pwd = request.POST['pwd']
        id = request.POST['id']
        user = authenticate(username=uname,password=pwd)

        try:
            if user.is_staff:
                login(request,user)
                error="no"
            else:
                error="yes"
        except:
            error="yes"

    dict_error={'error':error,'id':id}
    #print(dict_error)
    return render(request,'api_login.html',dict_error)
'''
class LoginView(APIView):
    def post(self,request):
        serializer = LoginSerializer(data = request.data)
        print(request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        login(request,user)
        token,created = Token.objects.get_or_create(user=user)
        return Response({"token":token.key}, status=200)
class LogoutView(APIView):
    authentication_classes = {TokenAuthentication,}

    def post(self,request):
        logout(request)
        return Response(status=204)

\
#@authentication_classes([TokenAuthentication,])
@api_view(['GET','POST'])
def check_id(request,sid):
    sid=sid.upper()
    print("****************")
    print(sid)
    doctor = Doctor.objects.filter(id=sid).values()
    print(doctor)
    if(len(doctor)>0):
        print(doctor)
        '''serializer is used to convert the model instances or querysets into the common language used by webservices'''
        serializer = DoctorSerializer(doctor,many = True)
        print("--------------")
        print(serializer.data)
        return Response(serializer.data)

    if(len(doctor)==0):
        patient =Patient.objects.filter(id=sid).values()
        if(len(patient)>0):
            print(patient)
            serializer = PatientSerializer(patient, many=True)
            print(serializer.data)
            return Response(serializer.data)
    if(len(patient)==0):
        appointment = Appointment.objects.filter(id=sid).values()
        if(len(appointment)>0):
            print(appointment)
            serializer = AppointmentSerializer(appointment, many=True)
            print(serializer.data)
            return Response(serializer.data)
    else:
        print("****************")
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)




@api_view(['GET','POST'])
def doctor_list(request,id,username,password):
    user = authenticate(username=username,password=password)
    if user.is_staff:
        if request.method == 'GET':
            id = id.upper()
            doctors = Doctor.objects.all()
            doctor_id= Doctor.objects.filter(id=id).values('name')
            appointment = Appointment.objects.filter(doctor=doctor_id[0]['name']).values('date').annotate(dcount=Count('date'))
            serializer = Appointment_Count_Serializer(appointment,many=True)
            print(serializer.data)
            return Response(serializer.data)
        elif request.method == 'POST':
            serializer = Appointment_Count_Serializer(data=request.data)
            if serializer.is_valid():
                serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    else:
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


def About(request):
    return render(request,'about.html')

def Index(request):
    if not request.user.is_staff:
        return redirect('login')
    return render(request,'index.html')

def Contact(request):
    return render(request,'contact.html')

def Login(request):
    error=""
    if request.method=='POST':
        uname = request.POST['uname']
        pwd = request.POST['pwd']
        user = authenticate(username=uname,password=pwd)

        try:
            if user.is_staff:
                login(request,user)
                error="no"
            else:
                error="yes"
        except:
            error="yes"
    dict_error={'error':error}
    return render(request,'login.html',dict_error)

def Logout_admin(request):
    if not request.user.is_staff:
        return redirect('login')
    logout(request)
    return redirect('login')

def View_Doctor(request):
    if not request.user.is_staff:
        return redirect('login')
    doct = Doctor.objects.all()
    dict_doct = {'doct':doct}
    return render(request,'view_doctor.html',dict_doct)

def Add_Doctor(request):
    error=""
    if not request.user.is_staff:
        return redirect('login')

    id_present = Doctor.objects.values_list('id')
    list_id_present = list(id_present)

    flag=0
    while(flag==0):
        response=requests.get("https://idgenerate.herokuapp.com/id/")
        id_generated = 'D'+str(response.json())
        if((f'{id_generated}',) not in list_id_present):
            flag=1

    if request.method=='POST':
        id = request.POST['id']
        name = request.POST['name']
        mobile = request.POST['mobile']
        special = request.POST['special']
        try:
            Doctor.objects.create(id=id,name=name,mobile=mobile,special=special)
            error="no"
        except:
            error="yes"
    dict_error={'error':error,'id':id_generated}
    return render(request,'add_doctor.html',dict_error)

def Delete_Doctor(request,did):
    if not request.user.is_staff:
        return redirect('login')
    del_doc = Doctor.objects.get(id=did)
    del_doc.delete()
    return redirect('view_doctor')

def View_Patient(request):
    if not request.user.is_staff:
        return redirect('login')
    pat = Patient.objects.all()
    dict_pat = {'pat':pat}
    return render(request,'view_patient.html',dict_pat)

def Add_Patient(request):
    error=""
    if not request.user.is_staff:
        return redirect('login')

    id_present = Patient.objects.values_list('id')
    list_id_present = list(id_present)
    print(list_id_present)
    flag=0
    while(flag==0):
        response=requests.get("https://idgenerate.herokuapp.com/id/")
        id_generated = 'P'+str(response.json())
        if((f'{id_generated}',) not in list_id_present):
            flag=1

    if request.method=='POST':
        id = request.POST['id']
        name = request.POST['name']
        gender = request.POST['gender']
        mobile = request.POST['mobile']
        address = request.POST['address']
        try:
            Patient.objects.create(id=id,name=name,gender=gender,mobile=mobile,address=address)
            error="no"
        except:
            error="yes"

    dict_error={'error':error,'id':id_generated}
    return render(request,'add_patient.html',dict_error)

def Delete_Patient(request,pid):
    if not request.user.is_staff:
        return redirect('login')
    del_doc = Patient.objects.get(id=pid)
    del_doc.delete()
    return redirect('view_patient')

def View_Appointment(request):
    if not request.user.is_staff:
        return redirect('login')
    appt = Appointment.objects.all()
    dict_appt = {'appt':appt}
    return render(request,'view_appointment.html',dict_appt)

def Book_Appointment(request):
    error=""
    if not request.user.is_staff:
        return redirect('login')
    id_present = Appointment.objects.values_list('id')
    list_id_present = list(id_present)
    flag=0
    while(flag==0):
        response=requests.get("https://idgenerate.herokuapp.com/id/")
        id_generated = 'A'+str(response.json())
        if((f'{id_generated}',) not in list_id_present):
            flag=1


    pat = Patient.objects.all()
    doc = Doctor.objects.all()
    if request.method=='POST':
        id = request.POST['id']
        doctor = request.POST['doctor']
        patient = request.POST['patient']
        dat = request.POST['date']
        time = request.POST['time']
#        date_time = request.POST['date-time']
        try:
            Appointment.objects.create(id=id,doctor=doctor,patient=patient,date=dat,time=time)
            error="no"
        except:
            error="yes"
    today = date.today()

    today = today.strftime("%Y-%m-%d")
    print(today)
    dict_book_appt={'error':error,'doc':doc,'pat':pat,'today':today,'id':id_generated}
    return render(request,'book_appointment.html',dict_book_appt)

def Delete_Appointment(request,aid):
    if not request.user.is_staff:
        return redirect('login')
    del_appt = Appointment.objects.get(id=aid)
    del_appt.delete()
    return redirect('view_appointment')

def DiagnoseView(request):
    operation = 'not_assigned'
    if not request.user.is_staff:
        return redirect('login')
    pat = Patient.objects.all()
    if request.method=="POST":
        operation = request.POST['operation']
        if(operation == "POST"):
            id = request.POST['id']
            patient_name = request.POST['patient_name']
            diagnose_name = request.POST['diagnose_name']
            refrence = request.POST['refrence']
            patient_type = request.POST['patient_type']

            data = {'diagnose':
                {
                'id':id,
                'patient_name':patient_name,
                'diagnose_name': diagnose_name,
                'refrence': refrence,
                'patient_type':patient_type}
            }
            response = requests.post("http://127.0.0.1:8000/diagnose/book_diagnose", json=data)
            diagnose_information = response.json()
            return render(request,'operation_selection.html',{'pat':pat,'operation':operation,'diagnose_information':diagnose_information['success']})

            #return render(request,'diagnose_information.html', {'diagnose_information': diagnose_information})

        if(operation == "GET"):
            print(operation)
            response =requests.get("http://127.0.0.1:8000/diagnose/book_diagnose")
            diagnose_information = response.json()
            print(diagnose_information['diagnose'])
            return render(request,'diagnose_information.html', {'diagnose_information': diagnose_information['diagnose']})

        if(operation =="PUT"):
            id = request.POST['id']
            patient_name = request.POST['patient_name']
            diagnose_name = request.POST['diagnose_name']
            refrence = request.POST['refrence']

            diagnose={}
            diagnose['id']=id
            if(patient_name):
                diagnose['patient_name']=patient_name
            if(diagnose_name):
                diagnose['diagnose_name']=diagnose_name
            if(refrence):
                diagnose['refrence']=refrence

            data = {'diagnose':diagnose}

            response = requests.put(f"http://127.0.0.1:8000/diagnose/book_diagnose/{id}", json=data)
            diagnose_information = response.json()

            return render(request,'operation_selection.html',{'pat':pat,'operation':operation,'diagnose_information':diagnose_information['success']})

            #return render(request,'diagnose_information.html', {'diagnose_information': diagnose_information})


        if(operation =="DELETE"):
            id = request.POST['id']
            response = requests.delete(f"http://127.0.0.1:8000/diagnose/book_diagnose/{id}")
            diagnose_information = response.json()
            #return render(request,'diagnose_information.html', {'diagnose_information': diagnose_information})
            return render(request,'operation_selection.html',{'pat':pat,'operation':operation,'diagnose_information':diagnose_information['success']})


    return render(request,'operation_selection.html',{'pat':pat,'operation':operation})

def DiagnoseOutPatientView(request):
    operation = 'not_assigned'
    if not request.user.is_staff:
        return redirect('login')
    response =requests.get("http://127.0.0.1:8000/diagnose/outpatient")
    diagnose_outpatient_information = response.json()
    print(diagnose_outpatient_information)
    return render(request,'diagnose_outpatient_information.html', {'diagnose_outpatient_information': diagnose_outpatient_information})


def PharmacyView(request):
    operation = 'not_assigned'
    if not request.user.is_staff:
        return redirect('login')
    if request.method=="POST":
        operation = request.POST['operation']
        if(operation == "POST"):
            id = request.POST['id']
            patient_name = request.POST['amount']


            data = {'amount':
                {
                'patientid_name':id,
                'amount': amount,
                }
            }
            response = requests.post("http://127.0.0.1:8000/medicine/list", json=data)
            diagnose_information = response.json()
            return render(request,'operation_selection.html',{'pat':pat,'operation':operation,'diagnose_information':diagnose_information['success']})

            #return render(request,'diagnose_information.html', {'diagnose_information': diagnose_information})

        if(operation == "GET"):
            print(operation)
            response =requests.get("http://127.0.0.1:8000/diagnose/")
            diagnose_information = response.json()
            print(diagnose_information['diagnose'])
            return render(request,'diagnose_information.html', {'diagnose_information': diagnose_information['diagnose']})




    return render(request,'operation_selection.html',{'pat':pat,'operation':operation})

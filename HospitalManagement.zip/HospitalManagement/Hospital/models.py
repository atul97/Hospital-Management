from django.db import models

# Create your models here.

class Doctor(models.Model):
    """docstring for Doctor."""
    id = models.CharField(max_length=15,primary_key = True)
    name = models.CharField(max_length=50)
    mobile = models.IntegerField()
    special = models.CharField(max_length=30)

    def __str__(self):
        return self.name

class Patient(models.Model):
    """docstring for Patient."""
    id = models.CharField(max_length=15,primary_key = True)
    name = models.CharField(max_length=50)
    gender = models.CharField(max_length=10)
    mobile = models.IntegerField()
    address = models.CharField(max_length=150)

    def __str__(self):
        return self.name

class Appointment(models.Model):
    """docstring for Appointment."""
    id = models.CharField(max_length=15,primary_key = True)
    doctor = models.CharField(max_length=30)
    patient = models.CharField(max_length=30)
    date = models.DateField()
    time = models.TimeField()

    def __str__(self):
        return self.doctor.name+"--"+self.patient.name

class Appointment_Count(models.Model):
    date = models.DateField()
    dcount = models.IntegerField()

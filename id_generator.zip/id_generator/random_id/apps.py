from django.apps import AppConfig


class RandomIdConfig(AppConfig):
    name = 'random_id'

from rest_framework import serializers
from random_id.models import idmodel,Medicine,BloodTestReport

class IdSerializer(serializers.ModelSerializer):
    class Meta:
        model = idmodel
        fields = "__all__"


from random_id.models import Diagnose

class DiagnoseSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    patient_name = serializers.CharField(max_length=120)
    diagnose_name = serializers.CharField()
    refrence = serializers.CharField()
    patient_type = serializers.CharField()
    date = serializers.DateField()

    def create(self, validated_data):
        return Diagnose.objects.create(**validated_data)

    def update(self, instance, validated_data):
        instance.id = validated_data.get('id', instance.id)
        instance.patient_name = validated_data.get('patient_name', instance.patient_name)
        instance.diagnose_name = validated_data.get('diagnose_name', instance.diagnose_name)
        instance.refrence = validated_data.get('refrence', instance.refrence)
        instance.patient_type = validated_data.get('patient_type',instance.patient_type)
        #print(instance)
        instance.save()
        return instance

class DiagnoseOutpatientSerializer(serializers.Serializer):
    patient_name = serializers.CharField(max_length=120)


class MedicineSerialzer(serializers.ModelSerializer):
    class Meta:
        model = Medicine
        fields = ['id','pharmacist','prescription','date']


class BloodTestReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = BloodTestReport
        fields ="__all__"

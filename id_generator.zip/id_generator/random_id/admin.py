from django.contrib import admin

from .models import *

admin.site.register(Diagnose)
admin.site.register(Medicine)
admin.site.register(BloodTestReport)

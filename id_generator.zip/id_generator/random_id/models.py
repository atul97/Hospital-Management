from django.db import models
from datetime import date
# Create your models here.

class idmodel(models.Model):
    """docstring for Doctor."""
    random_id = models.IntegerField()

class Diagnose(models.Model):
    id = models.IntegerField(primary_key = True)
    patient_name = models.CharField(max_length=20)
    diagnose_name = models.CharField(max_length=50)
    refrence = models.CharField(max_length=50)
    patient_type =  models.CharField(max_length=20,default="In-patient")
    date = models.DateField()


    def __str__(self):
        return self.diagnose_name

'''class Pharmacy(models.Model):
    id = models.IntegerField(primary_key = True)
    patient_name = models.CharField(max_length=20)
'''

class Medicine(models.Model):
	pharmacist = models.CharField(max_length =100)
	prescription = models.FileField()
	date = models.DateTimeField(auto_now_add=True)
	def __str__(self):
		return self.pharmacist

class BloodTestReport(models.Model):
    id = models.IntegerField(primary_key = True )
    haemoglobin = models.FloatField()
    rbc = models.FloatField()
    wbc = models.FloatField()
    report = models.CharField(max_length=100)
    alert = models.CharField(max_length=10)

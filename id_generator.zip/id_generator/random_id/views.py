from django.shortcuts import render
from random import randrange
from rest_framework.views import APIView
from rest_framework.response import Response
from random_id.serializer import IdSerializer,DiagnoseSerializer,DiagnoseOutpatientSerializer,MedicineSerialzer,BloodTestReportSerializer
# Create your views here.
from collections import OrderedDict
from datetime import date


class IdView(APIView):
    #print("**********************")
    def get(self, request):
        print("----------Start of WebService--------------")
        random_id = randrange(10000,99999)
        print(random_id)
        print(Response(random_id))
        return Response(random_id)


from django.shortcuts import get_object_or_404,redirect
from random_id.models import Diagnose,Medicine,BloodTestReport

class DiagnoseView(APIView):
    def get(self, request):

        #diagnose_data = Diagnose.get.all(pk=1)
        #print(diagnose_data)
        diagnose = Diagnose.objects.all()
        #print(diagnose)
        serializer = DiagnoseSerializer(diagnose, many=True)
        #print(serializer)
        return Response({"diagnose": serializer.data})

    def post(self, request):
        diagnose = request.data.get('diagnose')
        # Create an diagnose from the above data
        today = date.today()
        diagnose['date'] = today
        print(today)
        serializer = DiagnoseSerializer(data=diagnose)
        print(diagnose)

        if serializer.is_valid(raise_exception=True):
            diagnose_saved = serializer.save()
        if(diagnose_saved.diagnose_name == "Blood Test"):
            test_amount = 200
        elif(diagnose_saved.diagnose_name == "Urine Test"):
            test_amount = 300
        elif(diagnose_saved.diagnose_name == "Stool Test"):
            test_amount = 400

        return Response({"success": f"{diagnose_saved.diagnose_name} of {diagnose_saved.patient_name} booked successfully and Test Amount is {test_amount}"})

    def put(self, request, pk):
        # Get object with this pk and return 404 if articlr not found
        saved_diagnose = get_object_or_404(Diagnose.objects.all(), pk=pk)
        data = request.data.get('diagnose')
        print(type(data))
        serializer = DiagnoseSerializer(instance=saved_diagnose, data=data, partial=True)
        if serializer.is_valid(raise_exception=True):
            diagnose_saved = serializer.save()
        return Response({"success": f"{diagnose_saved.diagnose_name} of {diagnose_saved.patient_name} updated successfully"})

    def delete(self, request, pk):
        # Get object with this pk
        diagnose = get_object_or_404(Diagnose.objects.all(), pk=pk)
        diagnose.delete()
        return Response({"message": f"Diagnose with id `{pk}` has been deleted."})

class DiagnoseOutpatientView(APIView):
    def get(self,request):
        outpatient = Diagnose.objects.filter(patient_type = "Out-patient")
        serializer = DiagnoseOutpatientSerializer (outpatient, many=True)
        return Response(serializer.data)

class MedicineListView(APIView):
    def get(self,request):
        medicines = Medicine.objects.all()
        serializer = MedicineSerialzer(medicines,many=True)
        #print(Response(serializer.data))
        return Response(serializer.data)
    def post(self,request):
        serializer = MedicineSerialzer(data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status = status.HTTP_201_CREATED)

        return Response(serializer.error ,status=status.HTTP_400_BADREQUEST)

class MedicineDetailView(APIView):
    def get_object(self,pk):
        try:
             return Medicine.objects.get(pk=pk)

        except Exception :

            return Response(status=status.HTTP_404_NOT_FOUND)

    def get(self,request,pk):
        medicine = self.get_object(pk)
        serializer = MedicineSerialzer(medicine)
        return Response(serializer.data)

    def put(self,request,pk):
        medicine =self.get_object(pk)
        serializer = MedicineSerialzer(medicine,data=request.data)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data,status =status.HTTP_201_CREATED)
        return Response(serializer.error ,status=status.HTTP_400_BAD_REQUEST)


    def delete(self,request,pk):
        medicine =self.get_object(pk)
        medicine.delete()
        return Response(status =status.HTTP_204_NO_CONTENT)

class BloodTestReportView(APIView):
    def post(self,request):
        bloodtest_data = request.data.get('bloodtest_data')
        report = ''
        alert = "NO"

        if(bloodtest_data['haemoglobin']<12):
            alert = "YES"
            report+=" Haemoglobin is less than the normal Range"
        if(bloodtest_data['rbc']<4.2):
            alert = "YES"
            report+=" RBC is less than the normal Range"
        if(bloodtest_data['wbc']<4500):
            alert = "YES"
            report+=" WBC is less than the normal Range"
        if(report == ''):
            report = "Normal"
        bloodtest_data['report']=report
        bloodtest_data['alert']=alert
        serializer = BloodTestReportSerializer(data=bloodtest_data)
        if serializer.is_valid(raise_exception=True):
            bloodtest_data_saved = serializer.save()

        print(bloodtest_data)
        return Response({"success":"Data saved successfully"})
